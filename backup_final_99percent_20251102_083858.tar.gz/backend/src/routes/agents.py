"""
Agent management routes
"""
from flask import Blueprint, jsonify, request, current_app
from src.database import db
from src.models import Agent, User, Referral, Commission
from src.middleware.auth import jwt_required, get_current_user
from src.utils.decorators import handle_errors
from datetime import datetime

agents_bp = Blueprint('agents', __name__)


@agents_bp.route('/', methods=['GET'])
def list_agents():
    """List all agents (public - for display purposes)"""
    try:
        # Query users with agent-like roles
        users = User.query.filter(User.role.in_(['affiliate', 'master', 'supermaster'])).all()
        current_app.logger.info(f"DEBUG: Found {len(users)} users with agent roles")
        
        agents_data = []
        for user in users:
            agent_info = {
                'id': user.id,
                'name': f"{user.first_name} {user.last_name}" if user.first_name and user.last_name else user.email,
                'email': user.email,
                'role': user.role,
                'referral_code': user.referral_code,
                'is_active': user.is_active,
                'created_at': user.created_at.isoformat() if user.created_at else None
            }
            agents_data.append(agent_info)
        
        return jsonify({
            'agents': agents_data,
            'total': len(agents_data)
        }), 200
    except Exception as e:
        current_app.logger.error(f"Error in list_agents: {str(e)}")
        import traceback
        current_app.logger.error(traceback.format_exc())
        return jsonify({'error': f'Failed to fetch agents: {str(e)}'}), 500


@agents_bp.route('/', methods=['POST'])
@jwt_required
@handle_errors
def create_agent():
    """Create new agent (admin only)"""
    current_user = get_current_user()
    
    if current_user.role != 'admin':
        return jsonify({'error': 'Admin access required'}), 403
    
    data = request.get_json()
    
    # Check if user exists
    user = User.query.get(data.get('user_id'))
    if not user:
        return jsonify({'error': 'User not found'}), 404
    
    # Check if user already has agent profile
    if user.agent_profile:
        return jsonify({'error': 'User already has agent profile'}), 400
    
    # Generate unique agent code
    agent_code = Agent.generate_agent_code()
    while Agent.query.filter_by(agent_code=agent_code).first():
        agent_code = Agent.generate_agent_code()
    
    # Create agent
    agent = Agent(
        user_id=user.id,
        agent_code=agent_code,
        commission_rate=data.get('commission_rate', 10.0),
        is_active=True
    )
    
    db.session.add(agent)
    db.session.commit()
    
    return jsonify({
        'message': 'Agent created successfully',
        'agent': agent.to_dict()
    }), 201


@agents_bp.route('/<int:agent_id>', methods=['GET'])
@handle_errors
def get_agent(agent_id):
    """Get agent details"""
    agent = Agent.query.get_or_404(agent_id)
    return jsonify(agent.to_dict()), 200


@agents_bp.route('/<int:agent_id>', methods=['PUT'])
@jwt_required
@handle_errors
def update_agent(agent_id):
    """Update agent (admin only)"""
    current_user = get_current_user()
    
    if current_user.role != 'admin':
        return jsonify({'error': 'Admin access required'}), 403
    
    agent = Agent.query.get_or_404(agent_id)
    data = request.get_json()
    
    # Update fields
    if 'commission_rate' in data:
        agent.commission_rate = data['commission_rate']
    if 'is_active' in data:
        agent.is_active = data['is_active']
    
    db.session.commit()
    
    return jsonify({
        'message': 'Agent updated successfully',
        'agent': agent.to_dict()
    }), 200


@agents_bp.route('/<int:agent_id>', methods=['DELETE'])
@jwt_required
@handle_errors
def delete_agent(agent_id):
    """Delete agent (admin only)"""
    current_user = get_current_user()
    
    if current_user.role != 'admin':
        return jsonify({'error': 'Admin access required'}), 403
    
    agent = Agent.query.get_or_404(agent_id)
    agent.is_active = False
    db.session.commit()
    
    return jsonify({'message': 'Agent deactivated successfully'}), 200


@agents_bp.route('/<int:agent_id>/stats', methods=['GET'])
@handle_errors
def get_agent_stats(agent_id):
    """Get agent statistics"""
    agent = Agent.query.get_or_404(agent_id)
    
    # Get referrals
    referrals = Referral.query.filter_by(referrer_id=agent.user_id).all()
    
    # Get commissions
    commissions = Commission.query.filter_by(agent_id=agent.id).all()
    
    stats = {
        'total_referrals': len(referrals),
        'active_referrals': len([r for r in referrals if r.status == 'active']),
        'total_commissions': sum([c.amount for c in commissions]),
        'pending_commissions': sum([c.amount for c in commissions if c.status == 'pending']),
        'paid_commissions': sum([c.amount for c in commissions if c.status == 'paid'])
    }
    
    return jsonify(stats), 200


@agents_bp.route('/search', methods=['GET'])
@handle_errors
def search_agents():
    """Search agents by code or email"""
    query = request.args.get('q', '')
    
    if not query:
        return jsonify({'error': 'Search query required'}), 400
    
    agents = Agent.query.join(User).filter(
        db.or_(
            Agent.agent_code.ilike(f'%{query}%'),
            User.email.ilike(f'%{query}%')
        )
    ).all()
    
    return jsonify({
        'agents': [agent.to_dict() for agent in agents]
    }), 200

