"""
Commission routes
API endpoints for commission management
"""
from flask import Blueprint, request, jsonify, g
from src.utils.decorators import token_required, handle_errors, admin_required
from src.services.commission_service import CommissionService
from src.models import Commission, Agent, User
from src.database import db

commissions_bp = Blueprint('commissions', __name__, url_prefix='/api/v1/commissions')


@commissions_bp.route('/', methods=['GET'])
@token_required
@handle_errors
def get_commissions():
    """Get commissions for current user (if agent) or all (if admin)"""
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 20, type=int)
    status = request.args.get('status', None)
    
    # Check if user is an agent
    agent = Agent.query.filter_by(user_id=g.current_user.id).first()
    
    if agent:
        # Agent can only see their own commissions
        pagination = CommissionService.get_agent_commissions(
            agent_id=agent.id,
            status=status,
            page=page,
            per_page=per_page
        )
    elif g.current_user.role in ['supermaster', 'master', 'admin']:
        # Admin can see all commissions
        query = Commission.query
        
        if status:
            query = query.filter_by(status=status)
        
        # Filter by agent_id if provided
        agent_id = request.args.get('agent_id', type=int)
        if agent_id:
            query = query.filter_by(agent_id=agent_id)
        
        pagination = query.order_by(Commission.created_at.desc()).paginate(
            page=page, per_page=per_page, error_out=False
        )
    else:
        return jsonify({'error': 'Unauthorized'}), 403
    
    # Get detailed commission data
    commissions_data = []
    for commission in pagination.items:
        commission_dict = commission.to_dict()
        
        # Add agent info
        agent_obj = Agent.query.get(commission.agent_id)
        if agent_obj:
            agent_user = User.query.get(agent_obj.user_id)
            commission_dict['agent'] = {
                'id': agent_obj.id,
                'agent_code': agent_obj.agent_code,
                'name': f"{agent_user.first_name} {agent_user.last_name}" if agent_user else 'Unknown',
                'email': agent_user.email if agent_user else None
            }
        
        # Add challenge info
        if commission.challenge:
            commission_dict['challenge'] = {
                'id': commission.challenge.id,
                'program_id': commission.challenge.program_id,
                'status': commission.challenge.status
            }
        
        # Add referral info
        if commission.referral:
            referred_user = User.query.get(commission.referral.referred_user_id)
            commission_dict['referral'] = {
                'id': commission.referral.id,
                'referred_user': {
                    'id': referred_user.id if referred_user else None,
                    'name': f"{referred_user.first_name} {referred_user.last_name}" if referred_user else 'Unknown',
                    'email': referred_user.email if referred_user else None
                }
            }
        
        commissions_data.append(commission_dict)
    
    return jsonify({
        'commissions': commissions_data,
        'pagination': {
            'page': pagination.page,
            'per_page': pagination.per_page,
            'total': pagination.total,
            'pages': pagination.pages,
            'has_next': pagination.has_next,
            'has_prev': pagination.has_prev
        }
    }), 200


@commissions_bp.route('/stats', methods=['GET'])
@token_required
@handle_errors
def get_commission_stats():
    """Get commission statistics for current user (if agent) or specified agent (if admin)"""
    # Check if user is an agent
    agent = Agent.query.filter_by(user_id=g.current_user.id).first()
    
    if agent:
        # Agent can only see their own stats
        stats = CommissionService.get_agent_commission_stats(agent.id)
    elif g.current_user.role in ['supermaster', 'master', 'admin']:
        # Admin can see any agent's stats
        agent_id = request.args.get('agent_id', type=int)
        if not agent_id:
            return jsonify({'error': 'agent_id is required for admin'}), 400
        
        stats = CommissionService.get_agent_commission_stats(agent_id)
    else:
        return jsonify({'error': 'Unauthorized'}), 403
    
    if not stats:
        return jsonify({'error': 'Agent not found'}), 404
    
    return jsonify(stats), 200


@commissions_bp.route('/<int:commission_id>', methods=['GET'])
@token_required
@handle_errors
def get_commission(commission_id):
    """Get a specific commission"""
    commission = Commission.query.get_or_404(commission_id)
    
    # Check permissions
    agent = Agent.query.filter_by(user_id=g.current_user.id).first()
    
    if agent:
        # Agent can only see their own commissions
        if commission.agent_id != agent.id:
            return jsonify({'error': 'Unauthorized'}), 403
    elif g.current_user.role not in ['supermaster', 'master', 'admin']:
        return jsonify({'error': 'Unauthorized'}), 403
    
    commission_dict = commission.to_dict()
    
    # Add related data
    agent_obj = Agent.query.get(commission.agent_id)
    if agent_obj:
        agent_user = User.query.get(agent_obj.user_id)
        commission_dict['agent'] = {
            'id': agent_obj.id,
            'agent_code': agent_obj.agent_code,
            'name': f"{agent_user.first_name} {agent_user.last_name}" if agent_user else 'Unknown',
            'email': agent_user.email if agent_user else None
        }
    
    if commission.challenge:
        commission_dict['challenge'] = commission.challenge.to_dict()
    
    if commission.referral:
        referred_user = User.query.get(commission.referral.referred_user_id)
        commission_dict['referral'] = {
            'id': commission.referral.id,
            'referred_user': {
                'id': referred_user.id if referred_user else None,
                'name': f"{referred_user.first_name} {referred_user.last_name}" if referred_user else 'Unknown',
                'email': referred_user.email if referred_user else None
            }
        }
    
    return jsonify(commission_dict), 200


@commissions_bp.route('/<int:commission_id>/approve', methods=['POST'])
@admin_required
@handle_errors
def approve_commission(commission_id):
    """Approve a commission (Admin only)"""
    commission = CommissionService.approve_commission(
        commission_id=commission_id,
        approved_by_id=g.current_user.id
    )
    
    if not commission:
        return jsonify({'error': 'Commission not found or cannot be approved'}), 404
    
    return jsonify({
        'message': 'Commission approved successfully',
        'commission': commission.to_dict()
    }), 200


@commissions_bp.route('/<int:commission_id>/pay', methods=['POST'])
@admin_required
@handle_errors
def mark_commission_paid(commission_id):
    """Mark a commission as paid (Admin only)"""
    data = request.get_json()
    
    payment_method = data.get('payment_method')
    transaction_id = data.get('transaction_id')
    
    if not payment_method or not transaction_id:
        return jsonify({'error': 'payment_method and transaction_id are required'}), 400
    
    commission = CommissionService.mark_commission_paid(
        commission_id=commission_id,
        payment_method=payment_method,
        transaction_id=transaction_id
    )
    
    if not commission:
        return jsonify({'error': 'Commission not found or cannot be marked as paid'}), 404
    
    return jsonify({
        'message': 'Commission marked as paid successfully',
        'commission': commission.to_dict()
    }), 200


@commissions_bp.route('/summary', methods=['GET'])
@admin_required
@handle_errors
def get_commissions_summary():
    """Get overall commission summary (Admin only)"""
    from sqlalchemy import func
    from decimal import Decimal
    
    # Get total commissions by status
    pending = db.session.query(
        func.count(Commission.id).label('count'),
        func.sum(Commission.commission_amount).label('amount')
    ).filter(Commission.status == 'pending').first()
    
    approved = db.session.query(
        func.count(Commission.id).label('count'),
        func.sum(Commission.commission_amount).label('amount')
    ).filter(Commission.status == 'approved').first()
    
    paid = db.session.query(
        func.count(Commission.id).label('count'),
        func.sum(Commission.commission_amount).label('amount')
    ).filter(Commission.status == 'paid').first()
    
    # Get total sales
    total_sales = db.session.query(
        func.sum(Commission.sale_amount)
    ).scalar() or Decimal('0')
    
    # Get active agents count
    active_agents = Agent.query.filter_by(is_active=True).count()
    
    # Get agents with pending balance
    agents_with_balance = Agent.query.filter(
        Agent.pending_balance > 0
    ).count()
    
    return jsonify({
        'pending': {
            'count': pending.count or 0,
            'amount': float(pending.amount or 0)
        },
        'approved': {
            'count': approved.count or 0,
            'amount': float(approved.amount or 0)
        },
        'paid': {
            'count': paid.count or 0,
            'amount': float(paid.amount or 0)
        },
        'total_sales': float(total_sales),
        'active_agents': active_agents,
        'agents_with_balance': agents_with_balance
    }), 200

# ================================================================
# Additional Commission Routes - Add to existing commissions.py
# ================================================================

# Add these imports at the top
from src.services.commission_service import (
    get_agent_dashboard_stats,
    get_agent_customers,
    check_withdrawal_eligibility
)
from src.models import PaymentMethod

# ================================================================
# Agent Dashboard Routes
# ================================================================

@commissions_bp.route('/dashboard', methods=['GET'])
@token_required
@handle_errors
def get_agent_dashboard():
    """Get comprehensive dashboard stats for current agent"""
    # Get agent for current user
    agent = Agent.query.filter_by(user_id=g.current_user.id).first()
    
    if not agent:
        return jsonify({'error': 'Agent profile not found'}), 404
    
    stats = get_agent_dashboard_stats(agent.id)
    
    if 'error' in stats:
        return jsonify(stats), 400
    
    return jsonify(stats), 200


@commissions_bp.route('/customers', methods=['GET'])
@token_required
@handle_errors
def get_agent_customer_list():
    """Get all customers referred by current agent"""
    # Get agent for current user
    agent = Agent.query.filter_by(user_id=g.current_user.id).first()
    
    if not agent:
        return jsonify({'error': 'Agent profile not found'}), 404
    
    customers = get_agent_customers(agent.id)
    
    return jsonify({
        'customers': customers,
        'total': len(customers)
    }), 200


@commissions_bp.route('/eligibility', methods=['GET'])
@token_required
@handle_errors
def check_agent_withdrawal_eligibility():
    """Check if current agent can request a withdrawal"""
    # Get agent for current user
    agent = Agent.query.filter_by(user_id=g.current_user.id).first()
    
    if not agent:
        return jsonify({'error': 'Agent profile not found'}), 404
    
    eligibility = check_withdrawal_eligibility(agent.id)
    
    return jsonify(eligibility), 200


# ================================================================
# Payment Methods Routes
# ================================================================

@commissions_bp.route('/payment-methods', methods=['GET'])
@token_required
@handle_errors
def get_payment_methods():
    """Get all payment methods for current user"""
    methods = PaymentMethod.query.filter_by(
        user_id=g.current_user.id
    ).order_by(PaymentMethod.created_at.desc()).all()
    
    return jsonify({
        'payment_methods': [m.to_dict(mask_sensitive=True) for m in methods]
    }), 200


@commissions_bp.route('/payment-methods', methods=['POST'])
@token_required
@handle_errors
def create_payment_method():
    """Create or update payment method for current user"""
    data = request.get_json()
    
    method_type = data.get('method_type')
    if not method_type or method_type not in ['bank', 'paypal', 'crypto', 'wise']:
        return jsonify({'error': 'Invalid method_type'}), 400
    
    # Deactivate all existing methods
    PaymentMethod.query.filter_by(
        user_id=g.current_user.id
    ).update({'is_active': False})
    
    # Create new method
    method = PaymentMethod(
        user_id=g.current_user.id,
        method_type=method_type,
        is_active=True
    )
    
    # Set fields based on method type
    if method_type == 'bank':
        method.bank_name = data.get('bank_name')
        method.account_number = data.get('account_number')
        method.branch_number = data.get('branch_number')
        method.account_holder_name = data.get('account_holder_name')
        
        if not all([method.bank_name, method.account_number, method.account_holder_name]):
            return jsonify({'error': 'Missing required bank fields'}), 400
            
    elif method_type == 'paypal':
        method.paypal_email = data.get('paypal_email')
        
        if not method.paypal_email:
            return jsonify({'error': 'PayPal email is required'}), 400
            
    elif method_type == 'crypto':
        method.crypto_address = data.get('crypto_address')
        method.crypto_network = data.get('crypto_network')
        
        if not all([method.crypto_address, method.crypto_network]):
            return jsonify({'error': 'Crypto address and network are required'}), 400
            
        if method.crypto_network not in ['TRC20', 'ERC20', 'BEP20']:
            return jsonify({'error': 'Invalid crypto network'}), 400
            
    elif method_type == 'wise':
        method.wise_email = data.get('wise_email')
        
        if not method.wise_email:
            return jsonify({'error': 'Wise email is required'}), 400
    
    db.session.add(method)
    db.session.commit()
    
    return jsonify({
        'message': 'Payment method created successfully',
        'payment_method': method.to_dict(mask_sensitive=True)
    }), 201


@commissions_bp.route('/payment-methods/<int:method_id>', methods=['DELETE'])
@token_required
@handle_errors
def delete_payment_method(method_id):
    """Delete a payment method"""
    method = PaymentMethod.query.get_or_404(method_id)
    
    # Check ownership
    if method.user_id != g.current_user.id:
        return jsonify({'error': 'Unauthorized'}), 403
    
    db.session.delete(method)
    db.session.commit()
    
    return jsonify({'message': 'Payment method deleted successfully'}), 200


# ================================================================
# Enhanced Withdrawal Routes
# ================================================================

@commissions_bp.route('/withdrawals/request', methods=['POST'])
@token_required
@handle_errors
def request_withdrawal():
    """Request a new withdrawal"""
    # Get agent for current user
    agent = Agent.query.filter_by(user_id=g.current_user.id).first()
    
    if not agent:
        return jsonify({'error': 'Agent profile not found'}), 404
    
    # Check eligibility
    can_withdraw, reason, _ = agent.can_request_withdrawal()
    
    if not can_withdraw:
        return jsonify({'error': reason}), 400
    
    # Get active payment method
    payment_method = PaymentMethod.query.filter_by(
        user_id=g.current_user.id,
        is_active=True
    ).first()
    
    if not payment_method:
        return jsonify({'error': 'No active payment method. Please add one first.'}), 400
    
    data = request.get_json()
    amount = data.get('amount')
    
    if not amount or float(amount) <= 0:
        return jsonify({'error': 'Invalid amount'}), 400
    
    if float(amount) > agent.get_available_balance():
        return jsonify({'error': 'Amount exceeds available balance'}), 400
    
    # Create withdrawal request
    withdrawal = Withdrawal(
        agent_id=agent.id,
        user_id=g.current_user.id,
        amount=amount,
        fee=0,  # No fee for now
        net_amount=amount,
        payment_method=payment_method.method_type,
        payment_details=payment_method.to_json_snapshot(),
        status='pending',
        created_at=datetime.utcnow()
    )
    
    db.session.add(withdrawal)
    
    # Update last withdrawal date
    agent.last_withdrawal_date = datetime.utcnow()
    
    db.session.commit()
    
    return jsonify({
        'message': 'Withdrawal request submitted successfully',
        'withdrawal': withdrawal.to_dict()
    }), 201


@commissions_bp.route('/withdrawals', methods=['GET'])
@token_required
@handle_errors
def get_agent_withdrawals():
    """Get all withdrawals for current agent"""
    # Get agent for current user
    agent = Agent.query.filter_by(user_id=g.current_user.id).first()
    
    if not agent:
        return jsonify({'error': 'Agent profile not found'}), 404
    
    withdrawals = Withdrawal.query.filter_by(
        agent_id=agent.id
    ).order_by(Withdrawal.created_at.desc()).all()
    
    return jsonify({
        'withdrawals': [w.to_dict() for w in withdrawals]
    }), 200


# ================================================================
# Admin Withdrawal Management
# ================================================================

@commissions_bp.route('/admin/withdrawals/pending', methods=['GET'])
@admin_required
@handle_errors
def get_pending_withdrawals():
    """Get all pending withdrawal requests (Admin only)"""
    withdrawals = Withdrawal.query.filter_by(
        status='pending'
    ).order_by(Withdrawal.created_at.desc()).all()
    
    withdrawal_list = []
    for w in withdrawals:
        withdrawal_dict = w.to_dict()
        
        # Add agent info
        if w.agent:
            agent_user = User.query.get(w.agent.user_id)
            withdrawal_dict['agent'] = {
                'id': w.agent.id,
                'agent_code': w.agent.agent_code,
                'name': f"{agent_user.first_name} {agent_user.last_name}" if agent_user else 'Unknown',
                'email': agent_user.email if agent_user else None
            }
        
        withdrawal_list.append(withdrawal_dict)
    
    return jsonify({
        'withdrawals': withdrawal_list,
        'total': len(withdrawal_list)
    }), 200


@commissions_bp.route('/admin/withdrawals/<int:withdrawal_id>/approve', methods=['POST'])
@admin_required
@handle_errors
def approve_withdrawal(withdrawal_id):
    """Approve a withdrawal request (Admin only)"""
    withdrawal = Withdrawal.query.get_or_404(withdrawal_id)
    
    if withdrawal.status != 'pending':
        return jsonify({'error': 'Withdrawal is not pending'}), 400
    
    withdrawal.status = 'approved'
    withdrawal.approved_by = g.current_user.id
    withdrawal.approved_at = datetime.utcnow()
    
    db.session.commit()
    
    return jsonify({
        'message': 'Withdrawal approved successfully',
        'withdrawal': withdrawal.to_dict()
    }), 200


@commissions_bp.route('/admin/withdrawals/<int:withdrawal_id>/mark-paid', methods=['POST'])
@admin_required
@handle_errors
def mark_withdrawal_paid(withdrawal_id):
    """Mark withdrawal as paid (Admin only)"""
    withdrawal = Withdrawal.query.get_or_404(withdrawal_id)
    
    if withdrawal.status not in ['pending', 'approved']:
        return jsonify({'error': 'Withdrawal cannot be marked as paid'}), 400
    
    data = request.get_json()
    transaction_id = data.get('transaction_id')
    
    if not transaction_id:
        return jsonify({'error': 'transaction_id is required'}), 400
    
    # Update withdrawal
    withdrawal.status = 'completed'
    withdrawal.transaction_id = transaction_id
    withdrawal.completed_at = datetime.utcnow()
    
    if withdrawal.status == 'pending':
        withdrawal.approved_by = g.current_user.id
        withdrawal.approved_at = datetime.utcnow()
    
    # Update agent balance
    if withdrawal.agent:
        withdrawal.agent.pending_balance -= withdrawal.amount
        withdrawal.agent.total_withdrawn += withdrawal.amount
    
    db.session.commit()
    
    return jsonify({
        'message': 'Withdrawal marked as paid successfully',
        'withdrawal': withdrawal.to_dict()
    }), 200


@commissions_bp.route('/admin/withdrawals/<int:withdrawal_id>/reject', methods=['POST'])
@admin_required
@handle_errors
def reject_withdrawal(withdrawal_id):
    """Reject a withdrawal request (Admin only)"""
    withdrawal = Withdrawal.query.get_or_404(withdrawal_id)
    
    if withdrawal.status != 'pending':
        return jsonify({'error': 'Withdrawal is not pending'}), 400
    
    data = request.get_json()
    reason = data.get('reason', 'No reason provided')
    
    withdrawal.status = 'rejected'
    withdrawal.rejection_reason = reason
    
    db.session.commit()
    
    return jsonify({
        'message': 'Withdrawal rejected successfully',
        'withdrawal': withdrawal.to_dict()
    }), 200

