# Tasks module - import all tasks for Celery autodiscovery
from src.tasks.email_tasks import *
from src.tasks.course_drip_campaign import *
