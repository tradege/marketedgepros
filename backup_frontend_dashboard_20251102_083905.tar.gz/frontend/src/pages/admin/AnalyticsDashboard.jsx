import React, { useState, useEffect } from 'react';
import { Loader2, AlertCircle, RefreshCw, Radio } from 'lucide-react';
import axios from 'axios';
import LineChartComponent from '../../components/charts/LineChartComponent';
import BarChartComponent from '../../components/charts/BarChartComponent';
import PieChartComponent from '../../components/charts/PieChartComponent';

const API_BASE_URL = import.meta.env.VITE_API_URL || '/api/v1';

const AnalyticsDashboard = () => {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [timeRange, setTimeRange] = useState(30);
  const [analyticsData, setAnalyticsData] = useState(null);
  const [realTimeMetrics, setRealTimeMetrics] = useState(null);
  const [lastUpdated, setLastUpdated] = useState(null);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [autoRefresh, setAutoRefresh] = useState(true);

  // Fetch comprehensive analytics
  useEffect(() => {
    fetchAnalytics();
  }, [timeRange]);

  // Auto-refresh real-time metrics every 30 seconds
  useEffect(() => {
    if (autoRefresh) {
      fetchRealTimeMetrics();
      const interval = setInterval(() => {
        fetchRealTimeMetrics();
      }, 30000); // 30 seconds

      return () => clearInterval(interval);
    }
  }, [autoRefresh]);

  const fetchAnalytics = async () => {
    try {
      setLoading(true);
      setError(null);
      
      const token = localStorage.getItem('access_token');
      const response = await axios.get(
        `${API_BASE_URL}/analytics/comprehensive?days=${timeRange}`,
        {
          headers: {
            'Authorization': `Bearer ${token}`
          }
        }
      );
      
      setAnalyticsData(response.data.data);
      setLastUpdated(new Date());
    } catch (err) {
      setError('Failed to load analytics data. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const fetchRealTimeMetrics = async () => {
    try {
      const token = localStorage.getItem('access_token');
      const response = await axios.get(
        `${API_BASE_URL}/analytics/real-time-metrics`,
        {
          headers: {
            'Authorization': `Bearer ${token}`
          }
        }
      );
      
      setRealTimeMetrics(response.data.data);
      setLastUpdated(new Date());
    } catch (err) {
      console.error('Failed to fetch real-time metrics:', err);
    }
  };

  const handleRefresh = async () => {
    setIsRefreshing(true);
    await Promise.all([fetchAnalytics(), fetchRealTimeMetrics()]);
    setIsRefreshing(false);
  };

  const handleTimeRangeChange = (event) => {
    setTimeRange(event.target.value);
  };

  const formatLastUpdated = () => {
    if (!lastUpdated) return '';
    const now = new Date();
    const diff = Math.floor((now - lastUpdated) / 1000); // seconds
    
    if (diff < 60) return `${diff}s ago`;
    if (diff < 3600) return `${Math.floor(diff / 60)}m ago`;
    return lastUpdated.toLocaleTimeString();
  };

  if (loading) {
    return (
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 mt-8 mb-8">
        <div className="flex justify-center items-center min-h-[400px]">
          <Loader2 className="h-8 w-8 animate-spin text-gray-600 dark:text-gray-300" />
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 mt-8 mb-8">
        <div className="flex items-start gap-3 rounded-md border border-red-200 bg-red-50 p-4 text-red-800 dark:border-red-500/40 dark:bg-red-500/10 dark:text-red-200">
          <AlertCircle className="h-5 w-5 mt-0.5 shrink-0" />
          <div className="text-sm">{error}</div>
        </div>
      </div>
    );
  }

  if (!analyticsData) {
    return null;
  }

  // Prepare data for charts
  const revenueData = analyticsData.revenue_over_time || [];
  const userGrowthData = analyticsData.user_growth || [];
  const challengeStats = analyticsData.challenge_statistics || {};
  const kycStats = analyticsData.kyc_statistics || {};
  const referralStats = analyticsData.referral_statistics || {};
  const paymentStats = analyticsData.payment_statistics || {};

  // Transform challenge status distribution for pie chart
  const challengeStatusData = (challengeStats.status_distribution || []).map(item => ({
    name: item.status.charAt(0).toUpperCase() + item.status.slice(1),
    value: item.count
  }));

  // Transform KYC distribution for pie chart
  const kycDistributionData = (kycStats.distribution || []).map(item => ({
    name: item.status.charAt(0).toUpperCase() + item.status.slice(1).replace('_', ' '),
    value: item.count
  }));

  // Transform payment method distribution for bar chart
  const paymentMethodData = (paymentStats.method_distribution || []).map(item => ({
    name: item.method.charAt(0).toUpperCase() + item.method.slice(1),
    count: item.count,
    amount: item.total_amount
  }));

  return (
    <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 mt-8 mb-8">
      {/* Header with Real-time Controls */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between mb-6">
        <div>
          <h1 className="text-2xl sm:text-3xl font-semibold text-gray-900 dark:text-gray-100">
            Analytics Dashboard
          </h1>
          <div className="flex items-center gap-3 mt-2">
            {autoRefresh && (
              <div className="flex items-center gap-2 text-sm text-green-600 dark:text-green-400">
                <Radio className="h-4 w-4 animate-pulse" />
                <span>Live</span>
              </div>
            )}
            {lastUpdated && (
              <span className="text-sm text-gray-500 dark:text-gray-400">
                Updated {formatLastUpdated()}
              </span>
            )}
          </div>
        </div>
        
        <div className="flex flex-col sm:flex-row gap-3">
          {/* Auto-refresh toggle */}
          <button
            onClick={() => setAutoRefresh(!autoRefresh)}
            className={`px-4 py-2 rounded-md text-sm font-medium transition ${
              autoRefresh
                ? 'bg-green-100 text-green-700 hover:bg-green-200 dark:bg-green-900/30 dark:text-green-400 dark:hover:bg-green-900/50'
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200 dark:bg-gray-800 dark:text-gray-300 dark:hover:bg-gray-700'
            }`}
          >
            {autoRefresh ? 'Auto-refresh ON' : 'Auto-refresh OFF'}
          </button>

          {/* Manual refresh button */}
          <button
            onClick={handleRefresh}
            disabled={isRefreshing}
            className="flex items-center gap-2 px-4 py-2 rounded-md bg-blue-600 text-white hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition"
          >
            <RefreshCw className={`h-4 w-4 ${isRefreshing ? 'animate-spin' : ''}`} />
            Refresh
          </button>

          {/* Time range selector */}
          <div className="w-full sm:w-auto">
            <select
              id="timeRange"
              value={timeRange}
              onChange={handleTimeRangeChange}
              className="block w-full sm:min-w-[200px] rounded-md border border-gray-300 bg-white px-3 py-2 text-sm text-gray-900 shadow-sm outline-none transition focus:border-gray-900 focus:ring-2 focus:ring-gray-900/10 dark:border-gray-700 dark:bg-gray-900 dark:text-gray-100 dark:focus:border-gray-100 dark:focus:ring-gray-100/10"
            >
              <option value={7}>Last 7 days</option>
              <option value={30}>Last 30 days</option>
              <option value={90}>Last 90 days</option>
              <option value={180}>Last 6 months</option>
              <option value={365}>Last year</option>
            </select>
          </div>
        </div>
      </div>

      {/* Real-time Metrics Cards */}
      {realTimeMetrics && (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-6 border border-gray-200 dark:border-gray-700">
            <div className="text-sm font-medium text-gray-500 dark:text-gray-400">Active Users Today</div>
            <div className="text-2xl font-bold text-gray-900 dark:text-gray-100 mt-2">
              {realTimeMetrics.active_users_today || 0}
            </div>
          </div>
          
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-6 border border-gray-200 dark:border-gray-700">
            <div className="text-sm font-medium text-gray-500 dark:text-gray-400">Pending Payments</div>
            <div className="text-2xl font-bold text-gray-900 dark:text-gray-100 mt-2">
              {realTimeMetrics.pending_payments_count || 0}
            </div>
            <div className="text-sm text-gray-500 dark:text-gray-400 mt-1">
              ${(realTimeMetrics.pending_payments_amount || 0).toLocaleString()}
            </div>
          </div>
          
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-6 border border-gray-200 dark:border-gray-700">
            <div className="text-sm font-medium text-gray-500 dark:text-gray-400">Today's Revenue</div>
            <div className="text-2xl font-bold text-green-600 dark:text-green-400 mt-2">
              ${(realTimeMetrics.today_revenue || 0).toLocaleString()}
            </div>
          </div>
          
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-6 border border-gray-200 dark:border-gray-700">
            <div className="text-sm font-medium text-gray-500 dark:text-gray-400">Active Challenges</div>
            <div className="text-2xl font-bold text-gray-900 dark:text-gray-100 mt-2">
              {realTimeMetrics.active_challenges || 0}
            </div>
          </div>
        </div>
      )}

      <div className="grid grid-cols-12 gap-6">
        {/* Revenue Over Time */}
        <div className="col-span-12 lg:col-span-6">
          <LineChartComponent
            data={revenueData}
            title="Revenue Over Time"
            dataKeys={[
              { key: 'revenue', name: 'Revenue ($)' },
              { key: 'transactions', name: 'Transactions' }
            ]}
            colors={['#00C49F', '#8884D8']}
            height={350}
            yAxisLabel="Amount ($)"
          />
        </div>

        {/* User Growth */}
        <div className="col-span-12 lg:col-span-6">
          <LineChartComponent
            data={userGrowthData}
            title="User Growth"
            dataKeys={[
              { key: 'new_users', name: 'New Users' },
              { key: 'total_users', name: 'Total Users' }
            ]}
            colors={['#FF8042', '#0088FE']}
            height={350}
            yAxisLabel="Users"
          />
        </div>

        {/* Challenge Status Distribution */}
        <div className="col-span-12 lg:col-span-6">
          <PieChartComponent
            data={challengeStatusData}
            title="Challenge Status Distribution"
            height={350}
          />
        </div>

        {/* KYC Status Distribution */}
        <div className="col-span-12 lg:col-span-6">
          <PieChartComponent
            data={kycDistributionData}
            title="KYC Status Distribution"
            height={350}
          />
        </div>

        {/* Payment Methods */}
        <div className="col-span-12">
          <BarChartComponent
            data={paymentMethodData}
            title="Payment Methods Distribution"
            dataKeys={[
              { key: 'count', name: 'Count' },
              { key: 'amount', name: 'Amount ($)' }
            ]}
            colors={['#8884D8', '#82CA9D']}
            height={350}
            yAxisLabel="Count / Amount"
          />
        </div>
      </div>
    </div>
  );
};

export default AnalyticsDashboard;

