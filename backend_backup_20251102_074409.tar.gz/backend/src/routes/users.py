"""
User routes for profile and account management
"""
from flask import Blueprint, request, jsonify, g
from src.database import db
from src.models.user import User
from src.models.trading_program import Challenge
from src.models.payment import Payment
from src.utils.decorators import token_required
from datetime import datetime
from sqlalchemy import func, desc

users_bp = Blueprint('users', __name__)


@users_bp.route('/dashboard', methods=['GET'])
@token_required
def get_user_dashboard():
    """Get user dashboard statistics - works for all user types"""
    try:
        user = g.current_user
        
        # Get challenges count
        total_challenges = Challenge.query.filter_by(user_id=user.id).count()
        active_challenges = Challenge.query.filter_by(user_id=user.id, status='active').count()
        passed_challenges = Challenge.query.filter_by(user_id=user.id, status='passed').count()
        failed_challenges = Challenge.query.filter_by(user_id=user.id, status='failed').count()
        funded_challenges = Challenge.query.filter_by(user_id=user.id, status='funded').count()
        
        # Get total profit from all challenges
        challenges = Challenge.query.filter_by(user_id=user.id).all()
        total_profit = 0
        for challenge in challenges:
            if challenge.current_balance and challenge.initial_balance:
                profit = float(challenge.current_balance) - float(challenge.initial_balance)
                if profit > 0:
                    total_profit += profit
        
        # Get payments
        total_spent = db.session.query(func.sum(Payment.amount)).filter(
            Payment.user_id == user.id,
            Payment.status == 'completed',
            Payment.purpose == 'challenge_purchase'
        ).scalar() or 0
        
        # Get recent challenges
        recent_challenges = Challenge.query.filter_by(
            user_id=user.id
        ).order_by(desc(Challenge.created_at)).limit(5).all()
        
        # Calculate success rate
        completed_challenges = passed_challenges + failed_challenges
        success_rate = (passed_challenges / completed_challenges * 100) if completed_challenges > 0 else 0
        
        return jsonify({
            'user': {
                'id': user.id,
                'email': user.email,
                'first_name': user.first_name,
                'last_name': user.last_name,
                'role': user.role,
                'kyc_status': user.kyc_status,
                'is_verified': user.is_verified
            },
            'statistics': {
                'total_challenges': total_challenges,
                'active_challenges': active_challenges,
                'passed_challenges': passed_challenges,
                'failed_challenges': failed_challenges,
                'funded_challenges': funded_challenges,
                'success_rate': round(success_rate, 2),
                'total_profit': round(total_profit, 2),
                'total_spent': float(total_spent)
            },
            'recent_challenges': [{
                'id': challenge.id,
                'program_name': challenge.program.name if challenge.program else 'Unknown',
                'status': challenge.status,
                'phase': challenge.phase,
                'current_balance': float(challenge.current_balance) if challenge.current_balance else 0,
                'initial_balance': float(challenge.initial_balance) if challenge.initial_balance else 0,
                'profit': float(challenge.current_balance or 0) - float(challenge.initial_balance or 0),
                'created_at': challenge.created_at.isoformat() if challenge.created_at else None
            } for challenge in recent_challenges]
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@users_bp.route('/profile', methods=['GET'])
@token_required
def get_profile():
    """Get user profile"""
    try:
        user = g.current_user
        return jsonify(user.to_dict()), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@users_bp.route('/profile', methods=['PUT'])
@token_required
def update_profile():
    """Update user profile"""
    try:
        user = g.current_user
        data = request.get_json()
        
        # Update allowed fields
        if 'first_name' in data:
            user.first_name = data['first_name']
        if 'last_name' in data:
            user.last_name = data['last_name']
        if 'phone' in data:
            user.phone = data['phone']
        if 'country_code' in data:
            user.country_code = data['country_code']
        if 'date_of_birth' in data:
            user.date_of_birth = datetime.fromisoformat(data['date_of_birth'])
        
        db.session.commit()
        
        return jsonify({
            'message': 'Profile updated successfully',
            'user': user.to_dict()
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500




@users_bp.route('/tree', methods=['GET'])
@token_required
def get_users_tree():
    """Get users in tree structure for hierarchical display"""
    try:
        current_user = g.current_user
        
        # Helper function to build user dict with children count
        def build_user_dict(user):
            children_count = User.query.filter(
                User.tree_path.like(f"{user.tree_path}/%")
            ).count()
            
            user_dict = {
                'id': user.id,
                'first_name': user.first_name,
                'last_name': user.last_name,
                'email': user.email,
                'role': user.role,
                'is_active': user.is_active,
                'tree_path': user.tree_path,
                'parent_id': user.parent_id,
                'children_count': children_count,
                'commission_rate': float(user.commission_rate) if user.commission_rate else 0.0,
                'referral_code': user.referral_code if hasattr(user, 'referral_code') else None,
                'created_at': user.created_at.isoformat() if user.created_at else None
            }
            return user_dict
        
        # Check if user is Root (can_create_same_role=True)
        is_root = current_user.role == 'super_admin' and current_user.can_create_same_role
        
        if is_root:
            # Root users see all root-level users (those without parent or with can_create_same_role=True)
            root_users = User.query.filter(
                (User.parent_id == None) | (User.can_create_same_role == True)
            ).order_by(User.id).all()
        else:
            # Non-root users see themselves as root
            root_users = [current_user]
        
        tree = [build_user_dict(user) for user in root_users]
        
        return jsonify({
            'tree': tree,
            'total_count': len(tree)
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@users_bp.route('/<int:user_id>/children', methods=['GET'])
@token_required
def get_user_children(user_id):
    """Get direct children of a specific user"""
    try:
        current_user = g.current_user
        
        # Get the parent user
        parent_user = User.query.get(user_id)
        if not parent_user:
            return jsonify({'error': 'User not found'}), 404
        
        # Check permission - user can only see their own downline
        is_root = current_user.role == 'super_admin' and current_user.can_create_same_role
        if not is_root:
            # Check if parent_user is in current_user's downline
            if not (parent_user.id == current_user.id or 
                    (parent_user.tree_path and current_user.tree_path and 
                     parent_user.tree_path.startswith(current_user.tree_path + '/'))):
                return jsonify({'error': 'Permission denied'}), 403
        
        # Get direct children
        children = User.query.filter_by(parent_id=user_id).order_by(User.id).all()
        
        # Build response with children count for each child
        children_data = []
        for child in children:
            grandchildren_count = User.query.filter(
                User.tree_path.like(f"{child.tree_path}/%")
            ).count()
            
            child_dict = {
                'id': child.id,
                'first_name': child.first_name,
                'last_name': child.last_name,
                'email': child.email,
                'role': child.role,
                'is_active': child.is_active,
                'tree_path': child.tree_path,
                'parent_id': child.parent_id,
                'children_count': grandchildren_count,
                'commission_rate': float(child.commission_rate) if child.commission_rate else 0.0,
                'referral_code': child.referral_code if hasattr(child, 'referral_code') else None,
                'created_at': child.created_at.isoformat() if child.created_at else None
            }
            children_data.append(child_dict)
        
        return jsonify({
            'children': children_data,
            'total_count': len(children_data)
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

