"""
Flask extensions initialization
"""
from flask_mail import Mail

# Initialize Flask-Mail
mail = Mail()

