"""
Analytics Service
Provides advanced analytics and reporting functionality
"""
from datetime import datetime, timedelta
from sqlalchemy import func, and_, extract, case
from src.database import db
from src.models.user import User
from src.models.trading_program import Challenge
from src.models.payment import Payment
from src.models.commission import Commission
from src.models.referral import Referral
from src.models.agent import Agent
import logging

logger = logging.getLogger(__name__)


class AnalyticsService:
    """Service for analytics and reporting"""
    
    @staticmethod
    def get_revenue_over_time(days=30):
        """
        Get revenue data over time
        
        Args:
            days: Number of days to look back
            
        Returns:
            List of daily revenue data
        """
        try:
            start_date = datetime.utcnow() - timedelta(days=days)
            
            # Query daily revenue
            daily_revenue = db.session.query(
                func.date(Payment.created_at).label('date'),
                func.sum(Payment.amount).label('revenue'),
                func.count(Payment.id).label('transactions')
            ).filter(
                and_(
                    Payment.status == 'completed',
                    Payment.created_at >= start_date
                )
            ).group_by(
                func.date(Payment.created_at)
            ).order_by(
                func.date(Payment.created_at)
            ).all()
            
            return [{
                'date': str(row.date),
                'revenue': float(row.revenue),
                'transactions': row.transactions
            } for row in daily_revenue]
            
        except Exception as e:
            logger.error(f'Error getting revenue over time: {str(e)}')
            return []
    
    @staticmethod
    def get_user_growth(days=30):
        """
        Get user registration growth over time
        
        Args:
            days: Number of days to look back
            
        Returns:
            List of daily user registration data
        """
        try:
            start_date = datetime.utcnow() - timedelta(days=days)
            
            # Query daily registrations
            daily_users = db.session.query(
                func.date(User.created_at).label('date'),
                func.count(User.id).label('registrations'),
                func.sum(case((User.is_active == True, 1), else_=0)).label('active')
            ).filter(
                User.created_at >= start_date
            ).group_by(
                func.date(User.created_at)
            ).order_by(
                func.date(User.created_at)
            ).all()
            
            # Calculate cumulative total
            cumulative = 0
            result = []
            for row in daily_users:
                cumulative += row.registrations
                result.append({
                    'date': str(row.date),
                    'registrations': row.registrations,
                    'active': row.active,
                    'cumulative': cumulative
                })
            
            return result
            
        except Exception as e:
            logger.error(f'Error getting user growth: {str(e)}')
            return []
    
    @staticmethod
    def get_challenge_statistics(days=30):
        """
        Get challenge statistics over time
        
        Args:
            days: Number of days to look back
            
        Returns:
            Challenge statistics data
        """
        try:
            start_date = datetime.utcnow() - timedelta(days=days)
            
            # Query challenge status distribution
            status_distribution = db.session.query(
                Challenge.status,
                func.count(Challenge.id).label('count')
            ).filter(
                Challenge.created_at >= start_date
            ).group_by(
                Challenge.status
            ).all()
            
            # Query daily challenge creation
            daily_challenges = db.session.query(
                func.date(Challenge.created_at).label('date'),
                func.count(Challenge.id).label('created'),
                func.sum(case((Challenge.status == 'completed', 1), else_=0)).label('completed'),
                func.sum(case((Challenge.status == 'funded', 1), else_=0)).label('funded')
            ).filter(
                Challenge.created_at >= start_date
            ).group_by(
                func.date(Challenge.created_at)
            ).order_by(
                func.date(Challenge.created_at)
            ).all()
            
            return {
                'status_distribution': [{
                    'status': row.status,
                    'count': row.count
                } for row in status_distribution],
                'daily_data': [{
                    'date': str(row.date),
                    'created': row.created,
                    'completed': row.completed,
                    'funded': row.funded
                } for row in daily_challenges]
            }
            
        except Exception as e:
            logger.error(f'Error getting challenge statistics: {str(e)}')
            return {'status_distribution': [], 'daily_data': []}
    
    @staticmethod
    def get_kyc_statistics():
        """
        Get KYC verification statistics
        
        Returns:
            KYC statistics data
        """
        try:
            # Query KYC status distribution
            kyc_distribution = db.session.query(
                User.kyc_status,
                func.count(User.id).label('count')
            ).group_by(
                User.kyc_status
            ).all()
            
            # Query recent KYC submissions (last 30 days)
            thirty_days_ago = datetime.utcnow() - timedelta(days=30)
            recent_kyc = db.session.query(
                func.date(User.kyc_submitted_at).label('date'),
                func.count(User.id).label('submissions')
            ).filter(
                and_(
                    User.kyc_submitted_at.isnot(None),
                    User.kyc_submitted_at >= thirty_days_ago
                )
            ).group_by(
                func.date(User.kyc_submitted_at)
            ).order_by(
                func.date(User.kyc_submitted_at)
            ).all()
            
            return {
                'distribution': [{
                    'status': row.kyc_status or 'not_submitted',
                    'count': row.count
                } for row in kyc_distribution],
                'recent_submissions': [{
                    'date': str(row.date),
                    'submissions': row.submissions
                } for row in recent_kyc]
            }
            
        except Exception as e:
            logger.error(f'Error getting KYC statistics: {str(e)}')
            return {'distribution': [], 'recent_submissions': []}
    
    @staticmethod
    def get_referral_statistics():
        """
        Get referral and MLM statistics
        
        Returns:
            Referral statistics data
        """
        try:
            # Top performing agents
            top_agents = db.session.query(
                Agent.id,
                Agent.user_id,
                func.count(Referral.id).label('referral_count'),
                func.sum(Commission.commission_amount).label('total_commission')
            ).outerjoin(
                Referral, Referral.agent_id == Agent.id
            ).outerjoin(
                Commission, Commission.agent_id == Agent.id
            ).group_by(
                Agent.id, Agent.user_id
            ).order_by(
                func.count(Referral.id).desc()
            ).limit(10).all()
            
            # Get agent user details
            top_agents_data = []
            for row in top_agents:
                user = User.query.get(row.user_id)
                if user:
                    top_agents_data.append({
                        'agent_id': row.id,
                        'name': f"{user.first_name} {user.last_name}",
                        'email': user.email,
                        'referrals': row.referral_count,
                        'total_commission': float(row.total_commission or 0)
                    })
            
            # Referral conversion rate
            total_referrals = Referral.query.count()
            active_referrals = Referral.query.filter_by(status='active').count()
            conversion_rate = (active_referrals / total_referrals * 100) if total_referrals > 0 else 0
            
            return {
                'top_agents': top_agents_data,
                'total_referrals': total_referrals,
                'active_referrals': active_referrals,
                'conversion_rate': round(conversion_rate, 2)
            }
            
        except Exception as e:
            logger.error(f'Error getting referral statistics: {str(e)}')
            return {
                'top_agents': [],
                'total_referrals': 0,
                'active_referrals': 0,
                'conversion_rate': 0
            }
    
    @staticmethod
    def get_payment_statistics(days=30):
        """
        Get payment method and status statistics
        
        Args:
            days: Number of days to look back
            
        Returns:
            Payment statistics data
        """
        try:
            start_date = datetime.utcnow() - timedelta(days=days)
            
            # Payment method distribution
            method_distribution = db.session.query(
                Payment.payment_method,
                func.count(Payment.id).label('count'),
                func.sum(Payment.amount).label('total_amount')
            ).filter(
                and_(
                    Payment.created_at >= start_date,
                    Payment.status == 'completed'
                )
            ).group_by(
                Payment.payment_method
            ).all()
            
            # Payment status distribution
            status_distribution = db.session.query(
                Payment.status,
                func.count(Payment.id).label('count')
            ).filter(
                Payment.created_at >= start_date
            ).group_by(
                Payment.status
            ).all()
            
            return {
                'method_distribution': [{
                    'method': row.payment_method or 'unknown',
                    'count': row.count,
                    'total_amount': float(row.total_amount)
                } for row in method_distribution],
                'status_distribution': [{
                    'status': row.status,
                    'count': row.count
                } for row in status_distribution]
            }
            
        except Exception as e:
            logger.error(f'Error getting payment statistics: {str(e)}')
            return {'method_distribution': [], 'status_distribution': []}
    
    @staticmethod
    def get_comprehensive_analytics(days=30):
        """
        Get comprehensive analytics data for dashboard
        
        Args:
            days: Number of days to look back
            
        Returns:
            Comprehensive analytics data
        """
        try:
            return {
                'revenue_over_time': AnalyticsService.get_revenue_over_time(days),
                'user_growth': AnalyticsService.get_user_growth(days),
                'challenge_statistics': AnalyticsService.get_challenge_statistics(days),
                'kyc_statistics': AnalyticsService.get_kyc_statistics(),
                'referral_statistics': AnalyticsService.get_referral_statistics(),
                'payment_statistics': AnalyticsService.get_payment_statistics(days)
            }
        except Exception as e:
            logger.error(f'Error getting comprehensive analytics: {str(e)}')
            return {}


    @staticmethod
    def get_commission_analytics(days=30):
        """
        Get commission analytics over time
        
        Args:
            days: Number of days to look back
            
        Returns:
            Commission analytics data with totals, breakdown by type, top earners, and daily trend
        """
        try:
            from src.models.commission import Commission
            from src.models.agent import Agent
            from src.models.user import User
            
            start_date = datetime.utcnow() - timedelta(days=days)
            
            # Total commissions and amount
            totals = db.session.query(
                func.count(Commission.id).label('total_count'),
                func.sum(Commission.commission_amount).label('total_amount')
            ).filter(
                Commission.created_at >= start_date
            ).first()
            
            # Breakdown by status
            by_status = db.session.query(
                Commission.status,
                func.count(Commission.id).label('count'),
                func.sum(Commission.commission_amount).label('amount')
            ).filter(
                Commission.created_at >= start_date
            ).group_by(
                Commission.status
            ).all()
            
            # Top earning agents
            top_earners = db.session.query(
                Agent.id.label('agent_id'),
                User.first_name,
                User.last_name,
                User.email,
                func.sum(Commission.commission_amount).label('total_earned'),
                func.count(Commission.id).label('commission_count')
            ).join(
                Agent, Commission.agent_id == Agent.id
            ).join(
                User, Agent.user_id == User.id
            ).filter(
                Commission.created_at >= start_date
            ).group_by(
                Agent.id, User.first_name, User.last_name, User.email
            ).order_by(
                func.sum(Commission.commission_amount).desc()
            ).limit(10).all()
            
            # Daily trend
            daily_data = db.session.query(
                func.date(Commission.created_at).label('date'),
                func.sum(Commission.commission_amount).label('amount'),
                func.count(Commission.id).label('count')
            ).filter(
                Commission.created_at >= start_date
            ).group_by(
                func.date(Commission.created_at)
            ).order_by(
                func.date(Commission.created_at)
            ).all()
            
            # Create labels for all days
            labels = []
            data = []
            for i in range(days):
                date = (datetime.utcnow() - timedelta(days=days-1-i)).date()
                labels.append(date.strftime('%Y-%m-%d'))
                # Find data for this date
                day_amount = 0
                for row in daily_data:
                    if row.date == date:
                        day_amount = float(row.amount) if row.amount else 0
                        break
                data.append(day_amount)
            
            return {
                'total_commissions': totals.total_count or 0,
                'total_amount': float(totals.total_amount) if totals.total_amount else 0,
                'by_type': {
                    row.status: {
                        'count': row.count,
                        'amount': float(row.amount) if row.amount else 0
                    } for row in by_status
                },
                'top_earners': [{
                    'agent_id': row.agent_id,
                    'name': f"{row.first_name} {row.last_name}",
                    'email': row.email,
                    'total_earned': float(row.total_earned) if row.total_earned else 0,
                    'commission_count': row.commission_count
                } for row in top_earners],
                'daily_trend': {
                    'labels': labels,
                    'data': data
                }
            }
            
        except Exception as e:
            logger.error(f'Error getting commission analytics: {str(e)}')
            return {
                'total_commissions': 0,
                'total_amount': 0,
                'by_type': {},
                'top_earners': [],
                'daily_trend': {'labels': [], 'data': []}
            }

    @staticmethod
    def get_top_performers(limit=10, days=30):
        """
        Get top performing users
        
        Args:
            limit: Number of top performers to return
            days: Number of days to look back
            
        Returns:
            Top performers by revenue, referrals, and commissions
        """
        try:
            from src.models.payment import Payment
            from src.models.referral import Referral
            from src.models.commission import Commission
            from src.models.agent import Agent
            
            start_date = datetime.utcnow() - timedelta(days=days)
            
            # Top by revenue (payments)
            by_revenue = db.session.query(
                User.id.label('user_id'),
                User.first_name,
                User.last_name,
                User.email,
                func.sum(Payment.amount).label('total')
            ).join(
                Payment, User.id == Payment.user_id
            ).filter(
                and_(
                    Payment.status == 'completed',
                    Payment.created_at >= start_date
                )
            ).group_by(
                User.id, User.first_name, User.last_name, User.email
            ).order_by(
                func.sum(Payment.amount).desc()
            ).limit(limit).all()
            
            # Top by referrals
            by_referrals = db.session.query(
                User.id.label('user_id'),
                User.first_name,
                User.last_name,
                User.email,
                func.count(Referral.id).label('total')
            ).join(
                Agent, User.id == Agent.user_id
            ).join(
                Referral, Agent.id == Referral.agent_id
            ).filter(
                Referral.created_at >= start_date
            ).group_by(
                User.id, User.first_name, User.last_name, User.email
            ).order_by(
                func.count(Referral.id).desc()
            ).limit(limit).all()
            
            # Top by commissions
            by_commissions = db.session.query(
                User.id.label('user_id'),
                User.first_name,
                User.last_name,
                User.email,
                func.sum(Commission.commission_amount).label('total')
            ).join(
                Agent, User.id == Agent.user_id
            ).join(
                Commission, Agent.id == Commission.agent_id
            ).filter(
                Commission.created_at >= start_date
            ).group_by(
                User.id, User.first_name, User.last_name, User.email
            ).order_by(
                func.sum(Commission.commission_amount).desc()
            ).limit(limit).all()
            
            return {
                'by_revenue': [{
                    'user_id': row.user_id,
                    'username': f"{row.first_name} {row.last_name}",
                    'email': row.email,
                    'total': float(row.total) if row.total else 0
                } for row in by_revenue],
                'by_referrals': [{
                    'user_id': row.user_id,
                    'username': f"{row.first_name} {row.last_name}",
                    'email': row.email,
                    'total': row.total
                } for row in by_referrals],
                'by_commissions': [{
                    'user_id': row.user_id,
                    'username': f"{row.first_name} {row.last_name}",
                    'email': row.email,
                    'total': float(row.total) if row.total else 0
                } for row in by_commissions]
            }
            
        except Exception as e:
            logger.error(f'Error getting top performers: {str(e)}')
            return {
                'by_revenue': [],
                'by_referrals': [],
                'by_commissions': []
            }

    @staticmethod
    def get_real_time_metrics():
        """
        Get real-time metrics for dashboard
        
        Returns:
            Real-time metrics including active users, pending payments, revenue, etc.
        """
        try:
            from src.models.payment import Payment
            from src.models.commission import Commission
            from src.models.trading_program import Challenge
            
            today_start = datetime.utcnow().replace(hour=0, minute=0, second=0, microsecond=0)
            
            # Active users today (users who logged in or created today)
            active_users_today = db.session.query(
                func.count(func.distinct(User.id))
            ).filter(
                User.created_at >= today_start
            ).scalar() or 0
            
            # Pending payments
            pending_payments = db.session.query(
                func.count(Payment.id).label('count'),
                func.sum(Payment.amount).label('amount')
            ).filter(
                Payment.status == 'pending'
            ).first()
            
            # Today's revenue
            today_revenue = db.session.query(
                func.sum(Payment.amount)
            ).filter(
                and_(
                    Payment.status == 'completed',
                    Payment.created_at >= today_start
                )
            ).scalar() or 0
            
            # Today's commissions
            today_commissions = db.session.query(
                func.sum(Commission.commission_amount)
            ).filter(
                Commission.created_at >= today_start
            ).scalar() or 0
            
            # Active challenges
            active_challenges = db.session.query(
                func.count(Challenge.id)
            ).filter(
                Challenge.status == 'active'
            ).scalar() or 0
            
            return {
                'active_users_today': active_users_today,
                'pending_payments': pending_payments.count or 0,
                'pending_payments_amount': float(pending_payments.amount) if pending_payments.amount else 0,
                'today_revenue': float(today_revenue),
                'today_commissions': float(today_commissions),
                'active_challenges': active_challenges
            }
            
        except Exception as e:
            logger.error(f'Error getting real-time metrics: {str(e)}')
            return {
                'active_users_today': 0,
                'pending_payments': 0,
                'pending_payments_amount': 0,
                'today_revenue': 0,
                'today_commissions': 0,
                'active_challenges': 0
            }

    @staticmethod
    def get_conversion_funnel(days=30):
        """
        Get conversion funnel data
        
        Args:
            days: Number of days to look back
            
        Returns:
            Conversion funnel data showing user journey from registration to active trader
        """
        try:
            from src.models.payment import Payment
            
            start_date = datetime.utcnow() - timedelta(days=days)
            
            # Total registered users
            total_registered = db.session.query(
                func.count(User.id)
            ).filter(
                User.created_at >= start_date
            ).scalar() or 0
            
            # Email verified users
            email_verified = db.session.query(
                func.count(User.id)
            ).filter(
                and_(
                    User.created_at >= start_date,
                    User.email_verified_at.isnot(None)
                )
            ).scalar() or 0
            
            # Users with first payment
            first_payment = db.session.query(
                func.count(func.distinct(Payment.user_id))
            ).join(
                User, Payment.user_id == User.id
            ).filter(
                and_(
                    User.created_at >= start_date,
                    Payment.status == 'completed'
                )
            ).scalar() or 0
            
            # Active traders
            active_traders = db.session.query(
                func.count(User.id)
            ).filter(
                and_(
                    User.created_at >= start_date,
                    User.role == 'trader'
                )
            ).scalar() or 0
            
            # Calculate conversion rates
            verification_rate = (email_verified / total_registered * 100) if total_registered > 0 else 0
            payment_rate = (first_payment / email_verified * 100) if email_verified > 0 else 0
            trader_rate = (active_traders / first_payment * 100) if first_payment > 0 else 0
            
            return {
                'total_registered': total_registered,
                'email_verified': email_verified,
                'first_payment': first_payment,
                'active_traders': active_traders,
                'conversion_rates': {
                    'verification_rate': round(verification_rate, 2),
                    'payment_rate': round(payment_rate, 2),
                    'trader_rate': round(trader_rate, 2)
                }
            }
            
        except Exception as e:
            logger.error(f'Error getting conversion funnel: {str(e)}')
            return {
                'total_registered': 0,
                'email_verified': 0,
                'first_payment': 0,
                'active_traders': 0,
                'conversion_rates': {
                    'verification_rate': 0,
                    'payment_rate': 0,
                    'trader_rate': 0
                }
            }
