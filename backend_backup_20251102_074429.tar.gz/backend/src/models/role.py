"""
Role Model - Database-driven role management
UPDATED FOR PROFESSIONAL HIERARCHY
"""
from datetime import datetime
from src.database import db


class Role(db.Model):
    """Role model for managing user roles and permissions"""
    __tablename__ = 'roles'

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(50), unique=True, nullable=False)  # super_admin, admin, master, affiliate, trader
    label = db.Column(db.String(100), nullable=False)  # Super Admin, Admin, Master, Affiliate, Trader
    label_he = db.Column(db.String(100))  # Hebrew label
    color = db.Column(db.String(100))  # Tailwind CSS classes
    icon = db.Column(db.String(10))  # Emoji or icon
    hierarchy = db.Column(db.Integer, nullable=False)  # 1=highest, 5=lowest
    
    # Permissions (JSON)
    permissions = db.Column(db.JSON, default={})
    
    # Metadata
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def to_dict(self):
        """Convert role to dictionary"""
        return {
            'id': self.id,
            'name': self.name,
            'label': self.label,
            'label_he': self.label_he,
            'color': self.color,
            'icon': self.icon,
            'hierarchy': self.hierarchy,
            'permissions': self.permissions,
            'is_active': self.is_active,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }
    
    @staticmethod
    def seed_default_roles():
        """Seed default roles if they don't exist - PROFESSIONAL HIERARCHY"""
        default_roles = [
            {
                'name': 'super_admin',
                'label': 'Super Admin',
                'label_he': 'סופר אדמין',
                'color': 'bg-purple-100 text-purple-800',
                'icon': '👑',
                'hierarchy': 1,
                'permissions': {
                    'can_create_users': True,
                    'can_create_without_verification': True,
                    'can_manage_commissions': True,
                    'can_view_all_users': True,
                    'can_delete_users': True,
                    'can_manage_programs': True,
                    'can_manage_payments': True,
                    'can_manage_roles': True
                }
            },
            {
                'name': 'admin',
                'label': 'Admin',
                'label_he': 'אדמין',
                'color': 'bg-blue-100 text-blue-800',
                'icon': '⚡',
                'hierarchy': 2,
                'permissions': {
                    'can_create_users': True,
                    'can_create_without_verification': False,
                    'can_manage_commissions': False,
                    'can_view_all_users': False,
                    'can_delete_users': False,
                    'can_manage_programs': False,
                    'can_manage_payments': False,
                    'can_manage_roles': False
                }
            },
            {
                'name': 'master',
                'label': 'Master',
                'label_he': 'מאסטר',
                'color': 'bg-blue-100 text-blue-800',
                'icon': '⭐',
                'hierarchy': 3,
                'permissions': {
                    'can_create_users': True,
                    'can_create_without_verification': False,
                    'can_manage_commissions': False,
                    'can_view_all_users': False,
                    'can_delete_users': False,
                    'can_manage_programs': False,
                    'can_manage_payments': False,
                    'can_manage_roles': False
                }
            },
            {
                'name': 'affiliate',
                'label': 'Affiliate',
                'label_he': 'שותף',
                'color': 'bg-green-100 text-green-800',
                'icon': '🤝',
                'hierarchy': 4,
                'permissions': {
                    'can_create_users': False,
                    'can_create_without_verification': False,
                    'can_manage_commissions': False,
                    'can_view_all_users': False,
                    'can_delete_users': False,
                    'can_manage_programs': False,
                    'can_manage_payments': False,
                    'can_manage_roles': False
                }
            },
            {
                'name': 'trader',
                'label': 'Trader',
                'label_he': 'סוחר',
                'color': 'bg-gray-100 text-gray-800',
                'icon': '📊',
                'hierarchy': 5,
                'permissions': {
                    'can_create_users': False,
                    'can_create_without_verification': False,
                    'can_manage_commissions': False,
                    'can_view_all_users': False,
                    'can_delete_users': False,
                    'can_manage_programs': False,
                    'can_manage_payments': False,
                    'can_manage_roles': False
                }
            }
        ]
        
        for role_data in default_roles:
            existing_role = Role.query.filter_by(name=role_data['name']).first()
            if not existing_role:
                role = Role(**role_data)
                db.session.add(role)
        
        db.session.commit()


