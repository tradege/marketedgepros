"""
Admin routes for system management
"""
from flask import Blueprint, request, jsonify, g
from src import cache
import logging
from src.database import db
from src.models.user import User
from src.models.trading_program import Challenge
from src.models.payment import Payment
from src.models.trading_program import TradingProgram as Program
from src.utils.decorators import token_required, admin_required
from src.utils.validators import validate_required_fields, validate_email_format
from src.utils.error_messages import format_error_response
from src.utils.hierarchy_scoping import without_hierarchy_scope
from datetime import datetime, timedelta
from sqlalchemy import func, and_, or_

admin_bp = Blueprint('admin', __name__)


@admin_bp.route("/dashboard/stats", methods=["GET"])
@token_required
@admin_required
def get_dashboard_stats():
    """Get admin dashboard statistics"""
    try:
        # User statistics
        total_users = User.query.count()
        active_users = User.query.filter_by(is_active=True).count()
        pending_kyc = User.query.filter_by(kyc_status='pending').count()
        
        # Revenue statistics
        total_revenue = db.session.query(func.sum(Payment.amount)).filter(
            Payment.status == 'completed'
        ).scalar() or 0
        
        # Monthly revenue (last 30 days)
        thirty_days_ago = datetime.utcnow() - timedelta(days=30)
        monthly_revenue = db.session.query(func.sum(Payment.amount)).filter(
            and_(
                Payment.status == 'completed',
                Payment.created_at >= thirty_days_ago
            )
        ).scalar() or 0
        
        # Challenge statistics
        total_challenges = Challenge.query.count()
        active_challenges = Challenge.query.filter_by(status='active').count()
        completed_challenges = Challenge.query.filter_by(status='completed').count()
        failed_challenges = Challenge.query.filter_by(status='failed').count()
        funded_challenges = Challenge.query.filter_by(status='funded').count()
        
        # Recent users (last 5) - automatically filtered by hierarchy!
        recent_users = User.query.order_by(User.created_at.desc()).limit(5).all()
        
        # Recent payments (last 5)
        recent_payments = Payment.query.order_by(Payment.created_at.desc()).limit(5).all()
        
        return jsonify({
            'users': {
                'total': total_users,
                'active': active_users,
                'pending_kyc': pending_kyc,
                'suspended': User.query.filter_by(is_active=False).count()
            },
            'revenue': {
                'total': float(total_revenue),
                'monthly': float(monthly_revenue),
                'average_per_user': float(total_revenue / total_users) if total_users > 0 else 0
            },
            'challenges': {
                'total': total_challenges,
                'active': active_challenges,
                'completed': completed_challenges,
                'failed': failed_challenges,
                'funded': funded_challenges
            },
            'recent_users': [{
                'id': user.id,
                'name': f"{user.first_name} {user.last_name}",
                'email': user.email,
                'role': user.role,
                'status': 'active' if user.is_active else 'inactive',
                'created_at': user.created_at.isoformat()
            } for user in recent_users],
            'recent_payments': [{
                'id': payment.id,
                'user_id': payment.user_id,
                'amount': float(payment.amount),
                'type': payment.purpose,
                'status': payment.status,
                'created_at': payment.created_at.isoformat()
            } for payment in recent_payments]
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500


def _get_agent_data(user):
    """Helper function to safely get agent data"""
    try:
        if user.role not in ['agent', 'master', 'admin']:
            return None
        
        # Try to get agent relationship
        if hasattr(user, 'agent') and user.agent:
            return {
                'commission_rate': user.agent.commission_rate if hasattr(user.agent, 'commission_rate') else None,
                'pending_balance': float(user.agent.pending_balance) if hasattr(user.agent, 'pending_balance') and user.agent.pending_balance else 0,
                'paid_customers_count': user.agent.paid_customers_count if hasattr(user.agent, 'paid_customers_count') else 0,
                'can_withdraw': user.agent.can_withdraw if hasattr(user.agent, 'can_withdraw') else False
            }
        return None
    except Exception:
        return None

@admin_bp.route('/users', methods=['GET'])
@token_required
@admin_required
def get_users():
    """Get all users with filtering and pagination"""
    try:
        # Get query parameters
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 20, type=int)
        role = request.args.get('role')
        status = request.args.get('status')
        search = request.args.get('search')
        
        # Build query
        query = User.query
        
        # Apply hierarchy filtering
        current_user = g.current_user
        
        # Check if user is root
        is_root = current_user.role == 'super_admin' and current_user.can_create_same_role
        
        # Root super admin sees everything
        if is_root:
            # Root - no filtering, sees all users
            pass
        else:
            # Non-root user: only see their downline
            if current_user.tree_path:
                # Filter to users whose tree_path starts with current user's path
                # This includes descendants and the user themselves
                query = query.filter(
                    or_(
                        User.tree_path.like(current_user.tree_path + '/%'),
                        User.tree_path == current_user.tree_path
                    )
                )
            else:
                # User has no tree_path, only see themselves
                query = query.filter(User.id == current_user.id)
        
        # Apply filters
        if role:
            query = query.filter_by(role=role)
        if status:
            if status == 'active':
                query = query.filter_by(is_active=True)
            elif status == 'inactive':
                query = query.filter_by(is_active=False)
        if search:
            query = query.filter(
                or_(
                    User.email.ilike(f'%{search}%'),
                    User.first_name.ilike(f'%{search}%'),
                    User.last_name.ilike(f'%{search}%')
                )
            )
        
        # Get total count with hierarchy filtering applied
        # We need to count manually because paginate() doesn't apply our event-based filters to COUNT queries
        total_count = query.count()
        
        # Calculate pagination values
        total_pages = (total_count + per_page - 1) // per_page  # Ceiling division
        
        # Get the items for current page
        offset = (page - 1) * per_page
        users = query.order_by(User.created_at.desc()).limit(per_page).offset(offset).all()
        
        return jsonify({
            'users': [{
                'id': user.id,
                'email': user.email,
                'first_name': user.first_name,
                'last_name': user.last_name,
                'role': user.role,
                'is_active': user.is_active,
                'kyc_status': user.kyc_status,
                'phone': user.phone,
                'country_code': user.country_code,
                'parent_id': user.parent_id if hasattr(user, 'parent_id') else None,
                'level': user.level if hasattr(user, 'level') else 0,
                'referral_code': user.referral_code if hasattr(user, 'referral_code') else None,
                'created_at': user.created_at.isoformat() if user.created_at else None,
                'last_login_at': user.last_login_at.isoformat() if user.last_login_at else None,
                'commission_rate': float(user.commission_rate) if user.commission_rate else 0.00,
                'agent': _get_agent_data(user)
            } for user in users],
            'pagination': {
                'page': page,
                'per_page': per_page,
                'total': total_count,
                'pages': total_pages
            }
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@admin_bp.route('/users/<int:user_id>', methods=['GET'])
@token_required
@admin_required
def get_user(user_id):
    """Get specific user details"""
    try:
        # Apply hierarchy filtering
        current_user = g.current_user
        user = User.query.get_or_404(user_id)
        
        # Check if user is root
        is_root = current_user.tree_path and '/' not in current_user.tree_path
        
        # Root supermaster can view anyone
        if current_user.role == 'supermaster' and is_root:
            # Root supermaster - can view anyone
            pass
        else:
            # Non-root user: can only view users in their downline or themselves
            if user.id != current_user.id:
                # Check if user is in current_user's downline
                if not current_user.tree_path:
                    return jsonify({'error': 'Access denied'}), 403
                if not user.tree_path or not (user.tree_path.startswith(current_user.tree_path + '/') or user.tree_path == current_user.tree_path):
                    return jsonify({'error': 'Access denied'}), 403
        
        return jsonify({
            'id': user.id,
            'email': user.email,
            'first_name': user.first_name,
            'last_name': user.last_name,
            'role': user.role,
            'is_active': user.is_active,
            'kyc_status': user.kyc_status,
            'phone': user.phone,
            'country_code': user.country_code,
            'created_at': user.created_at.isoformat(),
            'updated_at': user.updated_at.isoformat(),
            'last_login_at': user.last_login_at.isoformat() if user.last_login_at else None,
            'is_verified': user.is_verified,
            'two_factor_enabled': user.two_factor_enabled
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@admin_bp.route('/users', methods=['POST'])
@token_required
@admin_required
def create_user():
    """Create a new user with comprehensive error handling"""
    try:
        data = request.get_json()
        
        # Validate required fields
        required_fields = ['email', 'password', 'first_name', 'last_name', 'role']
        missing_fields = [field for field in required_fields if not data.get(field)]
        
        if missing_fields:
            return jsonify(format_error_response(
                'MISSING_REQUIRED_FIELDS',
                fields=', '.join(missing_fields)
            )), 400
        
        # Validate email format
        valid, result = validate_email_format(data['email'])
        if not valid:
            return jsonify(format_error_response(
                'INVALID_EMAIL_FORMAT',
                email=data['email']
            )), 400
        
        # Check if user already exists (without hierarchy filtering)
        with without_hierarchy_scope(db.session):
            if User.query.filter_by(email=data['email']).first():
                return jsonify(format_error_response(
                    'USER_ALREADY_EXISTS'
                )), 400
        
        # Validate role
        allowed_roles = ['supermaster', 'super_admin', 'master', 'admin', 'agent', 'trader']
        if data['role'] not in allowed_roles:
            return jsonify(format_error_response(
                'INVALID_ROLE',
                roles=', '.join(allowed_roles)
            )), 400
        
        # Check if user can create same role
        if data['role'] == g.current_user.role:
            if not g.current_user.can_create_same_role:
                role_names = {
                    'supermaster': 'Supermaster',
                    'super_admin': 'Super Admin',
                    'master': 'Master',
                    'admin': 'Admin',
                    'agent': 'Agent'
                }
                return jsonify(format_error_response(
                    'CANNOT_CREATE_SAME_ROLE',
                    role=role_names.get(data['role'], data['role'])
                )), 403
        
        # Phone number validation and verification logic
        is_verified = False
        
        # Supermaster, super_admin, and admin can create users without phone
        # Note: agent is NOT included - agents cannot create users directly
        if g.current_user.role in ['supermaster', 'super_admin', 'admin']:
            is_verified = data.get('is_verified', True)  # Default to verified for admin-created users
        else:
            # Only non-admin roles require phone
            if data['role'] in ['admin', 'agent', 'trader']:
                if not data.get('phone'):
                    role_names = {
                        'admin': 'Master',
                        'agent': 'Agent',
                        'trader': 'Trader'
                    }
                    return jsonify(format_error_response(
                        'PHONE_REQUIRED_FOR_ROLE',
                        role=role_names.get(data['role'], data['role'])
                    )), 400
                
                # Force verification
                is_verified = True
        
        # Determine commission rate and parent
        commission_rate = 0.00
        parent_id = g.current_user.id
        
        # Special handling for Affiliate role
        if data['role'] == 'affiliate':
            # Affiliate always gets 15% and goes under Root
            commission_rate = 15.00
            # Find the root user (supermaster with no parent)
            root_user = User.query.filter_by(role='supermaster', parent_id=None).first()
            if root_user:
                parent_id = root_user.id
        else:
            # For other roles, use provided commission_rate or default to 0
            commission_rate = float(data.get('commission_rate', 0.00))
        
        # Create user WITHOUT hierarchy scoping to avoid recursion
        with without_hierarchy_scope(db.session):
            user = User(
                email=data['email'],
                first_name=data['first_name'],
                last_name=data['last_name'],
                role=data['role'],
                is_active=data.get('is_active', True),
                phone=data.get('phone'),
                country_code=data.get('country_code'),
                is_verified=is_verified,
                parent_id=parent_id,
                level=g.current_user.level + 1 if hasattr(g.current_user, 'level') else 1,
                commission_rate=commission_rate
            )
            user.set_password(data['password'])
            
            db.session.add(user)
            db.session.commit()
            
            # Build tree_path after commit
            if g.current_user.tree_path:
                user.tree_path = f"{g.current_user.tree_path}.{user.id}"
            else:
                user.tree_path = str(user.id)
            db.session.commit()
        
        # Generate referral code AFTER commit (to avoid NOT NULL issues)
        if user.role in ['supermaster', 'super_admin', 'admin', 'agent']:
            user.generate_referral_code()
            db.session.commit()
        
        # Create Agent profile for agents
        if user.role == 'agent':
            from src.models.agent import Agent
            agent = Agent(
                user_id=user.id,
                agent_code=user.referral_code,  # Use the same code as referral_code
                commission_rate=10.0,  # Default 10% commission
                is_active=True
            )
            db.session.add(agent)
            db.session.commit()
        
        return jsonify({
            'message': 'User created successfully',
            'user': {
                'id': user.id,
                'email': user.email,
                'first_name': user.first_name,
                'last_name': user.last_name,
                'role': user.role,
                'is_active': user.is_active,
                'referral_code': user.referral_code if hasattr(user, 'referral_code') else None
            }
        }), 201
        
    except Exception as e:
        db.session.rollback()
        # Log the actual error for debugging
        logging.error(f"Error creating user: {str(e)}", exc_info=True)
        return jsonify(format_error_response(
            'DATABASE_ERROR'
        )), 500


@admin_bp.route('/users/<int:user_id>', methods=['PUT'])
@token_required
@admin_required
def update_user(user_id):
    """Update user details"""
    try:
        user = User.query.get_or_404(user_id)
        data = request.get_json()
        
        # DEBUG: Log incoming data
        print(f"DEBUG UPDATE USER {user_id}: Received data = {data}")
        print(f"DEBUG: commission_rate in data = {'commission_rate' in data}")
        if 'commission_rate' in data:
            print(f"DEBUG: commission_rate value = {data['commission_rate']} (type: {type(data['commission_rate'])})")
            print(f"DEBUG: user.role = {user.role}")
        
        # Update allowed fields
        if 'first_name' in data:
            user.first_name = data['first_name']
        if 'last_name' in data:
            user.last_name = data['last_name']
        if 'phone' in data:
            user.phone = data['phone']
        if 'country_code' in data:
            user.country_code = data['country_code']
        if 'role' in data:
            user.role = data['role']
        if 'is_active' in data:
            user.is_active = data['is_active']
        if 'kyc_status' in data:
            user.kyc_status = data['kyc_status']
        
        # Update commission_rate
        if 'commission_rate' in data:
            print(f"DEBUG: Attempting to update commission_rate")
            # Don't allow changing Affiliate commission rate (always 15%)
            if user.role != 'affiliate':
                old_rate = user.commission_rate
                user.commission_rate = float(data['commission_rate'])
                print(f"DEBUG: Updated commission_rate from {old_rate} to {user.commission_rate}")
            else:
                print(f"DEBUG: Skipped - user is affiliate")
        
        user.updated_at = datetime.utcnow()
        db.session.commit()
        
        return jsonify({
            'message': 'User updated successfully',
            'user': {
                'id': user.id,
                'email': user.email,
                'first_name': user.first_name,
                'last_name': user.last_name,
                'role': user.role,
                'is_active': user.is_active,
                'kyc_status': user.kyc_status,
                'commission_rate': user.commission_rate
            }
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500


@admin_bp.route('/users/<int:user_id>', methods=['DELETE'])
@token_required
@admin_required
def delete_user(user_id):
    """Delete (soft delete) a user"""
    try:
        user = User.query.get_or_404(user_id)
        
        # Prevent self-deletion
        if user.id == g.current_user.id:
            return jsonify({'error': 'Cannot delete yourself'}), 400
        
        # Soft delete
        user.is_active = False
        user.updated_at = datetime.utcnow()
        db.session.commit()
        
        return jsonify({'message': 'User deleted successfully'}), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500


@admin_bp.route('/users/<int:user_id>/reset-password', methods=['POST'])
@token_required
@admin_required
def admin_reset_password(user_id):
    """Admin reset user password"""
    try:
        user = User.query.get_or_404(user_id)
        data = request.get_json()
        
        if 'new_password' not in data:
            return jsonify({'error': 'New password is required'}), 400
        
        user.set_password(data['new_password'])
        user.updated_at = datetime.utcnow()
        db.session.commit()
        
        return jsonify({'message': 'Password reset successfully'}), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500


@admin_bp.route('/programs', methods=['GET'])
@token_required
@admin_required
def get_programs():
    """Get all trading programs"""
    try:
        programs = Program.query.all()
        
        return jsonify({
            'programs': [{
                'id': program.id,
                'name': program.name,
                'description': program.description,
                'account_size': float(program.account_size),
                'profit_target': float(program.profit_target),
                'max_daily_loss': float(program.max_daily_loss),
                'max_total_loss': float(program.max_total_loss),
                'price': float(program.price),
                'is_active': program.is_active,
                'created_at': program.created_at.isoformat()
            } for program in programs]
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@admin_bp.route('/programs', methods=['POST'])
@token_required
@admin_required
def create_program():
    """Create a new trading program"""
    try:
        data = request.get_json()
        
        # Validate required fields
        required = ['name', 'account_size', 'profit_target', 'max_daily_loss', 'max_total_loss', 'price']
        valid, message = validate_required_fields(data, required)
        if not valid:
            return jsonify({'error': message}), 400
        
        program = Program(
            name=data['name'],
            description=data.get('description', ''),
            account_size=data['account_size'],
            profit_target=data['profit_target'],
            max_daily_loss=data['max_daily_loss'],
            max_total_loss=data['max_total_loss'],
            price=data['price'],
            is_active=data.get('is_active', True)
        )
        
        db.session.add(program)
        db.session.commit()
        
        return jsonify({
            'message': 'Program created successfully',
            'program': {
                'id': program.id,
                'name': program.name,
                'account_size': float(program.account_size)
            }
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500


@admin_bp.route('/programs/<int:program_id>', methods=['PUT'])
@token_required
@admin_required
def update_program(program_id):
    """Update a trading program"""
    try:
        program = Program.query.get_or_404(program_id)
        data = request.get_json()
        
        # Update fields
        if 'name' in data:
            program.name = data['name']
        if 'description' in data:
            program.description = data['description']
        if 'account_size' in data:
            program.account_size = data['account_size']
        if 'profit_target' in data:
            program.profit_target = data['profit_target']
        if 'max_daily_loss' in data:
            program.max_daily_loss = data['max_daily_loss']
        if 'max_total_loss' in data:
            program.max_total_loss = data['max_total_loss']
        if 'price' in data:
            program.price = data['price']
        if 'is_active' in data:
            program.is_active = data['is_active']
        
        program.updated_at = datetime.utcnow()
        db.session.commit()
        
        return jsonify({
            'message': 'Program updated successfully',
            'program': {
                'id': program.id,
                'name': program.name
            }
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500


@admin_bp.route('/programs/<int:program_id>', methods=['DELETE'])
@token_required
@admin_required
def delete_program(program_id):
    """Delete a trading program"""
    try:
        program = Program.query.get_or_404(program_id)
        
        # Check if program has active challenges
        active_challenges = Challenge.query.filter_by(
            program_id=program_id,
            status='active'
        ).count()
        
        if active_challenges > 0:
            return jsonify({'error': 'Cannot delete program with active challenges'}), 400
        
        db.session.delete(program)
        db.session.commit()
        
        return jsonify({'message': 'Program deleted successfully'}), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500


@admin_bp.route('/payments', methods=['GET'])
@token_required
@admin_required
def get_payments():
    """Get all payments with filtering"""
    try:
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 20, type=int)
        status = request.args.get('status')
        
        query = Payment.query
        
        if status:
            query = query.filter_by(status=status)
        
        pagination = query.order_by(Payment.created_at.desc()).paginate(
            page=page, per_page=per_page, error_out=False
        )
        
        return jsonify({
            'payments': [{
                'id': payment.id,
                'user_id': payment.user_id,
                'amount': float(payment.amount),
                'currency': payment.currency,
                'payment_type': payment.purpose,
                'payment_method': payment.payment_method,
                'status': payment.status,
                'transaction_id': payment.transaction_id,
                'created_at': payment.created_at.isoformat()
            } for payment in pagination.items],
            'pagination': {
                'page': pagination.page,
                'per_page': pagination.per_page,
                'total': pagination.total,
                'pages': pagination.pages
            }
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@admin_bp.route('/kyc/pending', methods=['GET'])
@token_required
@admin_required
def get_pending_kyc():
    """Get all pending KYC submissions"""
    try:
        users = User.query.filter_by(kyc_status='pending').all()
        
        return jsonify({
            'pending_kyc': [{
                'id': user.id,
                'email': user.email,
                'first_name': user.first_name,
                'last_name': user.last_name,
                'kyc_submitted_at': user.kyc_submitted_at.isoformat() if user.kyc_submitted_at else None,
                'kyc_id_url': user.kyc_id_url,
                'kyc_address_url': user.kyc_address_url,
                'kyc_selfie_url': user.kyc_selfie_url,
                'kyc_bank_url': user.kyc_bank_url
            } for user in users]
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@admin_bp.route('/kyc/<int:user_id>/approve', methods=['POST'])
@token_required
@admin_required
def approve_kyc(user_id):
    """Approve user KYC"""
    try:
        user = User.query.get_or_404(user_id)
        
        if user.kyc_status != 'pending':
            return jsonify({'error': 'KYC is not pending'}), 400
        
        user.kyc_status = 'approved'
        user.kyc_approved_at = datetime.utcnow()
        user.kyc_approved_by = g.current_user.id
        
        db.session.commit()
        
        return jsonify({'message': 'KYC approved successfully'}), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500


@admin_bp.route('/kyc/<int:user_id>/reject', methods=['POST'])
@token_required
@admin_required
def reject_kyc(user_id):
    """Reject user KYC"""
    try:
        user = User.query.get_or_404(user_id)
        data = request.get_json()
        
        if user.kyc_status != 'pending':
            return jsonify({'error': 'KYC is not pending'}), 400
        
        if 'reason' not in data:
            return jsonify({'error': 'Rejection reason is required'}), 400
        
        user.kyc_status = 'rejected'
        user.kyc_rejected_at = datetime.utcnow()
        user.kyc_rejected_by = g.current_user.id
        user.kyc_rejection_reason = data['reason']
        user.kyc_admin_notes = data.get('notes', '')
        
        db.session.commit()
        
        return jsonify({'message': 'KYC rejected successfully'}), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500




@admin_bp.route('/users/<int:user_id>/full-details', methods=['GET'])
@token_required
@admin_required
def get_user_full_details(user_id):
    """Get complete user details including downline, challenges, commissions, and payments"""
    try:
        user = User.query.get_or_404(user_id)
        
        # Basic user info
        user_data = {
            'id': user.id,
            'email': user.email,
            'first_name': user.first_name,
            'last_name': user.last_name,
            'role': user.role,
            'is_active': user.is_active,
            'kyc_status': user.kyc_status,
            'phone': user.phone,
            'country_code': user.country_code,
            'created_at': user.created_at.isoformat(),
            'updated_at': user.updated_at.isoformat(),
            'last_login_at': user.last_login_at.isoformat() if user.last_login_at else None,
            'is_verified': user.is_verified,
            'two_factor_enabled': user.two_factor_enabled
        }
        
        # Downline (for Master/Affiliate roles)
        downline_data = []
        if user.role in ['super_admin', 'admin', 'master', 'affiliate']:
            # Get direct referrals using parent_id
            children = User.query.filter_by(parent_id=user.id).all()
            for child in children:
                downline_data.append({
                    'id': child.id,
                    'name': f"{child.first_name} {child.last_name}",
                    'email': child.email,
                    'role': child.role,
                    'is_active': child.is_active,
                    'created_at': child.created_at.isoformat() if child.created_at else None,
                    'children_count': User.query.filter_by(parent_id=child.id).count()
                })
        
        # Trading challenges
        challenges_data = []
        challenges = Challenge.query.filter_by(user_id=user.id).all()
        for challenge in challenges:
            challenges_data.append({
                'id': challenge.id,
                'program_name': challenge.program.name if challenge.program else 'N/A',
                'account_size': float(challenge.initial_balance) if challenge.initial_balance else 0,
                'status': challenge.status,
                'current_balance': float(challenge.current_balance) if challenge.current_balance else 0,
                'profit_loss': float(challenge.total_profit or 0) - float(challenge.total_loss or 0),
                'created_at': challenge.created_at.isoformat() if challenge.created_at else None
            })
        
        # Payments
        payments_data = []
        payments = Payment.query.filter_by(user_id=user.id).all()
        for payment in payments:
            payments_data.append({
                'id': payment.id,
                'amount': float(payment.amount),
                'currency': payment.currency,
                'status': payment.status,
                'payment_type': payment.payment_type,
                'created_at': payment.created_at.isoformat() if payment.created_at else None
            })
        
        # Commissions (if applicable)
        commissions_data = {
            'total_earned': 0,
            'this_month': 0,
            'commission_rate': float(user.commission_rate) if hasattr(user, 'commission_rate') and user.commission_rate else 0
        }
        
        return jsonify({
            'user': user_data,
            'downline': {
                'direct_referrals': downline_data,
                'total_count': len(downline_data)
            },
            'challenges': {
                'list': challenges_data,
                'total_count': len(challenges_data),
                'active_count': len([c for c in challenges_data if c['status'] == 'active'])
            },
            'payments': {
                'list': payments_data,
                'total_count': len(payments_data),
                'total_amount': sum([p['amount'] for p in payments_data if p['status'] == 'completed'])
            },
            'commissions': commissions_data
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500




# /users/hierarchy endpoint removed - no longer needed!
# The regular /users endpoint now automatically filters by hierarchy
# Thanks to the centralized hierarchy scoping system!




@admin_bp.route('/users/tree', methods=['GET'])
@token_required
@admin_required
def get_users_tree():
    """Get users in tree structure with children count"""
    try:
        current_user = g.current_user
        
        # Check if user is root
        is_root = current_user.role == 'super_admin' and current_user.can_create_same_role
        
        # Build base query
        if is_root:
            # Root sees all users - get only top-level (no parent)
            query = User.query.filter(User.parent_id == None)
        else:
            # Non-root sees only their direct children
            query = User.query.filter(User.parent_id == current_user.id)
        
        users = query.order_by(User.created_at.desc()).all()
        
        # Build response with children count
        users_data = []
        for user in users:
            # Count children
            children_count = User.query.filter(User.parent_id == user.id).count()
            
            users_data.append({
                'id': user.id,
                'first_name': user.first_name,
                'last_name': user.last_name,
                'email': user.email,
                'role': user.role,
                'status': user.status,
                'commission_rate': float(user.commission_rate) if user.commission_rate else 0,
                'children_count': children_count,
                'has_children': children_count > 0,
                'level': 0 if is_root else 1,
                'parent_id': user.parent_id,
                'tree_path': user.tree_path,
                'referral_code': user.agent.referral_code if user.agent else None,
                'created_at': user.created_at.strftime('%m/%d/%Y') if user.created_at else None,
                'last_login': user.last_login.strftime('%m/%d/%Y') if user.last_login else 'Never'
            })
        
        return jsonify({
            'users': users_data,
            'total': len(users_data)
        }), 200
        
    except Exception as e:
        print(f"Error in get_users_tree: {str(e)}")
        return jsonify({'error': str(e)}), 500


@admin_bp.route('/users/<int:user_id>/children', methods=['GET'])
@token_required
@admin_required
def get_user_children(user_id):
    """Get children of a specific user"""
    try:
        current_user = g.current_user
        
        # Check permissions
        target_user = User.query.get(user_id)
        if not target_user:
            return jsonify({'error': 'Target user not found'}), 404
        
        # Check if current user can see this user's children
        is_root = current_user.role == 'super_admin' and current_user.can_create_same_role
        
        if not is_root:
            # Non-root can only see children of users in their downline
            if not target_user.tree_path or not target_user.tree_path.startswith(current_user.tree_path):
                return jsonify({'error': 'Permission denied'}), 403
        
        # Get children
        children = User.query.filter(User.parent_id == user_id).order_by(User.created_at.desc()).all()
        
        # Calculate level based on tree_path
        parent_level = len(target_user.tree_path.split('/')) - 1 if target_user.tree_path else 0
        child_level = parent_level + 1
        
        children_data = []
        for child in children:
            # Count grandchildren
            grandchildren_count = User.query.filter(User.parent_id == child.id).count()
            
            children_data.append({
                'id': child.id,
                'first_name': child.first_name,
                'last_name': child.last_name,
                'email': child.email,
                'role': child.role,
                'status': child.status,
                'commission_rate': float(child.commission_rate) if child.commission_rate else 0,
                'children_count': grandchildren_count,
                'has_children': grandchildren_count > 0,
                'level': child_level,
                'parent_id': child.parent_id,
                'tree_path': child.tree_path,
                'referral_code': child.agent.referral_code if child.agent else None,
                'created_at': child.created_at.strftime('%m/%d/%Y') if child.created_at else None,
                'last_login': child.last_login.strftime('%m/%d/%Y') if child.last_login else 'Never'
            })
        
        return jsonify({
            'children': children_data,
            'total': len(children_data)
        }), 200
        
    except Exception as e:
        print(f"Error in get_user_children: {str(e)}")
        return jsonify({'error': str(e)}), 500

