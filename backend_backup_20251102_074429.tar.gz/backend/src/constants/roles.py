"""
Role constants for the application - PROFESSIONAL HIERARCHY
Synchronized with database structure
"""

# Role definitions
class Roles:
    """Role constants"""
    SUPER_ADMIN = 'super_admin'
    ADMIN = 'admin'
    MASTER = 'master'
    AFFILIATE = 'affiliate'
    TRADER = 'trader'
    GUEST = 'guest'
    
    # All admin roles (can access admin panel)
    ADMIN_ROLES = [SUPER_ADMIN, ADMIN, MASTER]
    
    # All super admin roles (highest level)
    SUPER_ADMIN_ROLES = [SUPER_ADMIN]
    
    # All admin level roles
    ADMIN_LEVEL_ROLES = [ADMIN]
    
    # All master roles
    MASTER_ROLES = [MASTER]
    
    # All roles
    ALL_ROLES = [SUPER_ADMIN, ADMIN, MASTER, AFFILIATE, TRADER, GUEST]
    
    @staticmethod
    def is_admin(role):
        """Check if role is admin level"""
        return role in Roles.ADMIN_ROLES
    
    @staticmethod
    def is_super_admin(role):
        """Check if role is super admin level"""
        return role in Roles.SUPER_ADMIN_ROLES
    
    @staticmethod
    def is_admin_level(role):
        """Check if role is admin level"""
        return role in Roles.ADMIN_LEVEL_ROLES
    
    @staticmethod
    def is_master(role):
        """Check if role is master level"""
        return role in Roles.MASTER_ROLES
    
    @staticmethod
    def is_affiliate(role):
        """Check if role is affiliate level"""
        return role == Roles.AFFILIATE
    
    @staticmethod
    def normalize_role(role):
        """Normalize role to new naming convention"""
        role_mapping = {
            'agent': 'affiliate',  # Map old agent role to affiliate
            'supermaster': 'super_admin',  # Map old supermaster to super_admin
        }
        return role_mapping.get(role, role)
    
    @staticmethod
    def get_display_name(role):
        """Get display name for role"""
        display_names = {
            'super_admin': 'Super Admin',
            'admin': 'Admin',
            'master': 'Master',
            'affiliate': 'Affiliate',
            'trader': 'Trader',
            'guest': 'Guest',
        }
        return display_names.get(role, role.title())


# Role hierarchy for user creation permissions
# PROFESSIONAL HIERARCHY
ROLE_HIERARCHY = {
    # Super Admin (Root) can create: Super Admin, Admin, Master, Affiliate, Trader
    # Super Admin (regular) can create: Admin, Master, Affiliate, Trader (NOT Super Admin)
    # Distinction is made by can_create_same_role flag
    'super_admin': ['admin', 'master', 'affiliate', 'trader'],
    
    # Admin can create: Master, Affiliate only (NOT Trader)
    'admin': ['master', 'affiliate'],
    
    # Master can create: Affiliate only (NOT Trader)
    'master': ['affiliate'],
    
    # Affiliate cannot create anyone (only gets referral code)
    # Traders register via referral code and are auto-assigned
    'affiliate': [],
    
    # Trader cannot create anyone
    'trader': [],
    
    # Guest cannot create anyone
    'guest': []
}


def can_user_create_role(user_role, target_role, is_root_super_admin=False):
    """
    Check if a user with user_role can create a user with target_role
    
    Args:
        user_role: The role of the user trying to create
        target_role: The role being created
        is_root_super_admin: True if the user is the root Super Admin (can_create_same_role=True)
    
    Returns:
        bool: True if allowed, False otherwise
    """
    # Root Super Admin can create another Super Admin
    if is_root_super_admin and user_role == Roles.SUPER_ADMIN and target_role == Roles.SUPER_ADMIN:
        return True
    
    # Check normal hierarchy
    allowed_roles = ROLE_HIERARCHY.get(user_role, [])
    return target_role in allowed_roles


# Hierarchy rules documentation
HIERARCHY_RULES = """
MarketEdgePros Professional Hierarchy System:

1. Super Admin (Root):
   - Identified by: can_create_same_role = True
   - Can create: Super Admin, Admin, Master, Affiliate, Trader
   - Has: Full system access
   - Dashboard: Admin Dashboard with all features

2. Super Admin (Regular):
   - Identified by: role = 'super_admin' AND can_create_same_role = False
   - Can create: Admin, Master, Affiliate, Trader (NOT Super Admin)
   - Has: Access to all users below them in hierarchy
   - Dashboard: Admin Dashboard (limited)

3. Admin:
   - Can create: Master, Affiliate only (NOT Trader)
   - Has: Access to Masters and Affiliates below them
   - Dashboard: Admin Dashboard
   - Note: Traders can only be created by Super Admin or via referral code

4. Master:
   - Can create: Affiliate only (NOT Trader)
   - Has: Access to Affiliates below them
   - Dashboard: Master Dashboard
   - Note: Traders can only be created by Super Admin or via referral code

5. Affiliate:
   - Can create: Nobody (uses referral code instead)
   - Has: Unique referral code for marketing
   - Sees: Only Traders who registered via their referral code
   - Dashboard: Affiliate Dashboard (stats, commissions, payouts)
   - Note: When a Trader registers with their referral code, the Trader is auto-created

6. Trader:
   - End user
   - Cannot create anyone
   - Dashboard: Trader Dashboard (challenges, payouts, trading)
   - Can only be created by: Super Admin directly OR via Affiliate referral code

Registration Rules:
- User registers via website → goes under Root Super Admin as Trader
- User registers via Affiliate referral code → goes under that Affiliate as Trader
- Admin/Master cannot create Traders directly (only via Super Admin or referral)
- Each user can only see/manage users in their downline
- No "jumping" levels in hierarchy
"""


